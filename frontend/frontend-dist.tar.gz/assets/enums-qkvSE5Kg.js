const E={UNSCREENED:"待筛选",REJECTED:"暂不合适",PENDING:"待联系",CONTACTED:"已联系",COMMUNICATING:"沟通中",COOPERATING:"合作中",DORMANT:"休眠中",PAUSED:"暂不合作",BLACKLIST:"黑名单",TERMINATED:"不再合作"};export{E as S};
